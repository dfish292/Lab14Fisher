﻿using Android.App;
using Android.Widget;
using Android.OS;
using MU.IT;

namespace UWO.IT
{
    [Activity(Label = "Instructors", MainLauncher = true)]
    public class MainActivity : Activity
    {

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            var instructorList = FindViewById<ListView>(Resource.Id.instructorListView);

            instructorList.Adapter = new ArrayAdapter(this,
                                                        Android.Resource.Layout.SimpleListItem1,
                                                        InstructorData.Instructors);
        }
    }
}

